/* @author Thomas Ansill
 * @course CSCI-331-01
 * @assignment Project 2
 */
/** Species enum */
public enum Species{
    DOVE, HAWK
}